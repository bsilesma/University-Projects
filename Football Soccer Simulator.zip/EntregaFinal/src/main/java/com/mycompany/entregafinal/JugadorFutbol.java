package com.mycompany.entregafinal;

public abstract class JugadorFutbol {

    // Atributos de los jugadores
    protected int id;
    protected String nombre;
    protected String equipo;
    protected int goles;
    protected int acciones;

    // Constructor
    public JugadorFutbol(String nombre) {
        this.id = 0;
        this.nombre = nombre;
        this.equipo = "Ninguno";
        this.goles = 0;
        this.acciones = 0;
    }

    //Metodo para luego modificarlo en cada clase hija
    public abstract String generarMensaje();

    //Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEquipo() {
        return equipo;
    }

    public void setEquipo(String equipo) {
        this.equipo = equipo;
    }

    public int getGoles() {
        return goles;
    }

    public void setGoles(int goles) {
        this.goles = goles;
    }

    public int getAcciones() {
        return acciones;
    }

    public void setAcciones(int acciones) {
        this.acciones = acciones;
    }

    //toString
    @Override
    public String toString() {
        return "JugadorFutbol{" + "goles=" + goles + '}';
    }

    // Metodo para obtener el rol del jugador 
    public String getRol() {
        return this.getClass().getSimpleName();
    }

}

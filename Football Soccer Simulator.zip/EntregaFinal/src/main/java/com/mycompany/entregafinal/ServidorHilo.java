package com.mycompany.entregafinal;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServidorHilo extends Thread {

    // Atributos
    private int puerto;
    private Gestion gestor;

    // Constructor
    public ServidorHilo(int puerto) {
        this.puerto = puerto;
        this.gestor = new Gestion(); // Instanciamos gestor para obtener de BD
    }

    public void run() {
        try {
            // Instancia y abre puerto
            ServerSocket servidor = new ServerSocket(puerto);
            System.out.println("Servidor iniciado en el puerto " + puerto);

            while (true) {
                // Espera para atender cliente
                System.out.println("Esperando cliente");
                Socket cliente = servidor.accept();
                System.out.println("Cliente conectado desde: " + cliente.getInetAddress());

                // Prepara la comunicación
                DataInputStream entrada = new DataInputStream(cliente.getInputStream());
                DataOutputStream salida = new DataOutputStream(cliente.getOutputStream());

                // Lee la peticion
                String peticion = entrada.readUTF();
                System.out.println("Cliente pide: " + peticion);

                String respuesta = "";

                // Respuesta según lo que pide
                if (peticion.equals("POSICIONES")) {
                    respuesta = gestor.getReportePosiciones();
                } else if (peticion.equals("GOLEADORES")) {
                    respuesta = gestor.getReporteGoleadores();
                } else if (peticion.equals("HISTORIAL")) {
                    respuesta = gestor.getReporteHistorial();
                } else if (peticion.equals("RENDIMIENTO")) {
                    respuesta = gestor.getReporteRendimiento();
                } // -------------------
                else {
                    respuesta = "Error: Peticion invalida";
                }

                // Enviamos la respuesta real
                salida.writeUTF(respuesta);

                // Cierra llamada
                cliente.close();
            }

        } catch (IOException e) {
            System.out.println("Error en el servidor: " + e.getMessage());
        }
    }
}

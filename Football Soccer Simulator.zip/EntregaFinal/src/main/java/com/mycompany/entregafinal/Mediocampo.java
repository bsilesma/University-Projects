package com.mycompany.entregafinal;

public class Mediocampo extends JugadorFutbol {

    // Mensajes predeterminados del mediocampista
    private final String[] mensajes = {
        "cambia de ritmo y distribuye el juego",
        "recupera y lanza un pase entre línea",
        "toca y se mueve para dar salida",
        "presiona alto y fuerza el error"
    };

    // Hereda todo de clase madre
    public Mediocampo(String nombre) {
        super(nombre);
    }

    //toString
    @Override
    public String generarMensaje() {
        int indiceAleatorio = (int) (Math.random() * mensajes.length);
        String frase = mensajes[indiceAleatorio];
        return String.format("[Equipo: %s] %s %s", this.equipo, this.nombre, frase);
    }
}

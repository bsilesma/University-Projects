
package com.mycompany.entregafinal;

public class Delantero extends JugadorFutbol {

    // Mensajes predeterminados del delantero
    private final String[] mensajes = {
        "se desmarca y define cruzad",
        "controla de espaldas y asiste al compañero",
        "prueba de media distancia y casi anota",
        "gana la posición y remata de primera."
    };

    // Hereda todo de la clase madre
    public Delantero(String nombre) {
        super(nombre);
    }

    // toString
    @Override
    public String generarMensaje() {
        int indiceAleatorio = (int) (Math.random() * mensajes.length);
        String frase = mensajes[indiceAleatorio];
        return "[Equipo: " + this.equipo + "] " + this.nombre + " " + frase;
    }
}

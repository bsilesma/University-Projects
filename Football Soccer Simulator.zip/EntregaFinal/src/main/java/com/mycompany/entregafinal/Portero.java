package com.mycompany.entregafinal;

public class Portero extends JugadorFutbol {

    // Mensajes predeterminados del portero
    private final String[] mensajes = {
        "vuela y ataja un disparo a ras de piso.",
        "ordena la defensa y pide calma desde el arco",
        "sale rápido y corta un mano a mano",
        "bloquea con reflejos felinos y evita el gol"
    };

    // Hereda todo de clase madre
    public Portero(String nombre) {
        super(nombre);
    }

    // toString
    @Override
    public String generarMensaje() {

        int indiceAleatorio = (int) (Math.random() * mensajes.length);
        String frase = mensajes[indiceAleatorio];
        return "[Equipo: " + this.equipo + "] " + this.nombre + " " + frase;
    }
}

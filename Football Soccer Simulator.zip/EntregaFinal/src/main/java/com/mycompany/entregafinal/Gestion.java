package com.mycompany.entregafinal;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.util.ArrayList;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;

public class Gestion {

    // Metodo para agregar jugadores a BD
    public boolean agregarJugador(JugadorFutbol jugador) {
        Conexion conexion = new Conexion();
        String sql = "INSERT INTO jugadores (nombre, tipo_rol, nombre_equipo, goles, acciones) VALUES (?, ?, ?, ?, ?)";

        try {
            Connection con = conexion.conectar(); //Instancia
            CallableStatement cs = con.prepareCall(sql);
            cs.setString(1, jugador.getNombre());
            cs.setString(2, jugador.getRol());
            cs.setString(3, jugador.getEquipo());
            cs.setInt(4, jugador.getGoles());
            cs.setInt(5, jugador.getAcciones());

            cs.execute();
            return true;

        } catch (Exception ex) {
            // Si algo sale mal agregando jugadores, imprime:
            System.out.println("Error al agregar: " + ex.getMessage());
            return false;
        } finally {
            conexion.desconectar();
        }
    }

    // Metodo para eliminar jugadores 
    public boolean eliminarJugador(int id) {
        Conexion conexion = new Conexion();
        String sql = "DELETE FROM jugadores WHERE id = ?";

        try {
            Connection con = conexion.conectar();
            CallableStatement cs = con.prepareCall(sql);
            cs.setInt(1, id);
            cs.execute();
            return true;
        } catch (Exception ex) {
            // Si algo sale mal eliminando jugadores, imprime:
            System.out.println("Error al eliminar: " + ex.getMessage());
            return false;
        } finally {
            conexion.desconectar();
        }
    }

    // Metodo para obtener los jugadores por consulta
    public DefaultTableModel consultarJugadores() {
        Conexion conexion = new Conexion();
        DefaultTableModel modelo = new DefaultTableModel();

        // Se define las columnas
        modelo.addColumn("ID");
        modelo.addColumn("NOMBRE");
        modelo.addColumn("POSICION");
        modelo.addColumn("EQUIPO");
        modelo.addColumn("GOLES");
        modelo.addColumn("ACCIONES");

        String sql = "SELECT * FROM jugadores";
        String[] datos = new String[6];

        try {
            Connection con = conexion.conectar();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                datos[0] = rs.getString("id");
                datos[1] = rs.getString("nombre");
                datos[2] = rs.getString("tipo_rol");
                datos[3] = rs.getString("nombre_equipo");
                datos[4] = rs.getString("goles");
                datos[5] = rs.getString("acciones");
                modelo.addRow(datos);
            }
        } catch (Exception ex) {
            // Si algo sale mal con la consulta, imprime:
            System.out.println("Error al consultar: " + ex.getMessage());
        } finally {
            conexion.desconectar();
        }
        return modelo;
    }

    // Obtiene los datos de equipos para el cb
    public DefaultComboBoxModel obtenerModeloEquipos() {
        Conexion conexion = new Conexion();
        DefaultComboBoxModel modeloCombo = new DefaultComboBoxModel();

        // Por default
        modeloCombo.addElement("Ninguno");

        String sql = "SELECT nombre FROM equipos";

        try {
            Connection con = conexion.conectar();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                String nombreEquipo = rs.getString("nombre");
                if (!nombreEquipo.equalsIgnoreCase("Ninguno")) {
                    modeloCombo.addElement(nombreEquipo);
                }
            }
        } catch (Exception ex) {
            // Si algo sale mal con la consulta con la DB, imprime:
            System.out.println("Error al cargar equipos: " + ex.getMessage());
        } finally {
            conexion.desconectar();
        }
        return modeloCombo;
    }

    // Metodo para la simulacion, obtiene los jugadores
    public ArrayList<JugadorFutbol> getJugadoresPorEquipo(String nombreEquipo) {
        ArrayList<JugadorFutbol> lista = new ArrayList<>();
        Conexion conexion = new Conexion();

        // Obtiene los que coincide por nombre de equipo
        String sql = "SELECT * FROM jugadores WHERE nombre_equipo = '" + nombreEquipo + "'";

        try {
            Connection con = conexion.conectar();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                String nombre = rs.getString("nombre");
                String rol = rs.getString("tipo_rol");

                // Crea los jugadores dependiendo del rol
                JugadorFutbol jugador = null;

                if (rol.equalsIgnoreCase("Portero")) {
                    jugador = new Portero(nombre);
                } else if (rol.equalsIgnoreCase("Defensa")) {
                    jugador = new Defensa(nombre);
                } else if (rol.equalsIgnoreCase("Mediocampo")) {
                    jugador = new Mediocampo(nombre);
                } else if (rol.equalsIgnoreCase("Delantero")) {
                    jugador = new Delantero(nombre);
                } else {
                    jugador = new Defensa(nombre); // Por defecto
                }

                // Llena los demás datos
                jugador.setId(rs.getInt("id"));
                jugador.setEquipo(nombreEquipo);
                jugador.setGoles(rs.getInt("goles"));

                lista.add(jugador);
            }
        } catch (Exception ex) {
            // Si algo sale mal cargando los equipos, imprime:
            System.out.println("Error al cargar equipo: " + ex.getMessage());
        } finally {
            conexion.desconectar();
        }
        return lista;
    }

    // Metodo para guardar los datos del partido
    public void registrarPartido(Equipo local, Equipo visita, int golesLocal, int golesVisita) {
        Conexion conexion = new Conexion();

        try {
            Connection con = conexion.conectar();

            // Inserta todo usando precall
            String sqlPartido = "INSERT INTO partidos (equipoA, equipoB, golesA, golesB, fecha) VALUES (?, ?, ?, ?, NOW())";
            CallableStatement cs = con.prepareCall(sqlPartido);
            cs.setString(1, local.getNombre());
            cs.setString(2, visita.getNombre());
            cs.setInt(3, golesLocal);
            cs.setInt(4, golesVisita);
            cs.execute();

            // Aqui calcula los pntos
            int puntosLocal = 0;
            int puntosVisita = 0;

            if (golesLocal > golesVisita) {
                puntosLocal = 3;
            } else if (golesVisita > golesLocal) {
                puntosVisita = 3;
            } else {
                puntosLocal = 1;
                puntosVisita = 1;
            }

            // Actualiza los datos de equipo local
            String sqlUpdateLocal = "UPDATE equipos SET partidos_jugados = partidos_jugados + 1, "
                    + "goles_favor = goles_favor + ?, goles_contra = goles_contra + ?, "
                    + "puntos = puntos + ? WHERE nombre = ?";

            CallableStatement csL = con.prepareCall(sqlUpdateLocal);
            csL.setInt(1, golesLocal);
            csL.setInt(2, golesVisita);
            csL.setInt(3, puntosLocal);
            csL.setString(4, local.getNombre());
            csL.execute();

            // Actualiza los datos de equipo visitante
            String sqlUpdateVisita = "UPDATE equipos SET partidos_jugados = partidos_jugados + 1, "
                    + "goles_favor = goles_favor + ?, goles_contra = goles_contra + ?, "
                    + "puntos = puntos + ? WHERE nombre = ?";

            CallableStatement csV = con.prepareCall(sqlUpdateVisita);
            csV.setInt(1, golesVisita);
            csV.setInt(2, golesLocal);
            csV.setInt(3, puntosVisita);
            csV.setString(4, visita.getNombre());
            csV.execute();

            System.out.println("Partido guardado correctamente");

        } catch (Exception ex) {
            // Si algo sale mal guardando todo, imprime:
            System.out.println("Error al guardar partido: " + ex.getMessage());
        } finally {
            conexion.desconectar();
        }
    }

    //Metodo para crear el reporte
    public String getReportePosiciones() {

        //Instancia la conexion
        Conexion conexion = new Conexion();
        StringBuilder reporte = new StringBuilder();

        // Diseños
        reporte.append("TABLA DE POSICIONES\n");
        reporte.append(String.format("%-15s %5s %5s %5s %5s %5s\n", "EQUIPO", "PJ", "PG", "PE", "PP", "PTS"));
        reporte.append("--------------------------------------------------\n");

        String sql = "SELECT nombre, partidos_jugados, victorias, empates, derrotas, puntos FROM equipos ORDER BY puntos DESC, goles_favor DESC";

        try {
            Connection con = conexion.conectar();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                String linea = String.format("%-15s %5d %5d %5d %5d %5d\n",
                        rs.getString("nombre"),
                        rs.getInt("partidos_jugados"),
                        rs.getInt("victorias"),
                        rs.getInt("empates"),
                        rs.getInt("derrotas"),
                        rs.getInt("puntos")
                );
                reporte.append(linea);
            }
        } catch (Exception ex) {
            // Si algo sale mal creando el reporte, imprime:
            return "Error al generar reporte: " + ex.getMessage();
        } finally {
            conexion.desconectar();
        }
        return reporte.toString();

    }

    // Metodo para crear el reporte de goleadores
    public String getReporteGoleadores() {

        //Instancia la conexion
        Conexion conexion = new Conexion();
        StringBuilder reporte = new StringBuilder();

        reporte.append("TOP GOLEADORES\n");
        reporte.append(String.format("%-20s %-15s %5s\n", "JUGADOR", "EQUIPO", "GOLES"));
        reporte.append("--------------------------------------------------\n");

        // Obtiene los que tengan minimo 1 gol
        String sql = "SELECT nombre, nombre_equipo, goles FROM jugadores WHERE goles > 0 ORDER BY goles DESC";

        try {
            Connection con = conexion.conectar();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                String linea = String.format("%-20s %-15s %5d\n",
                        rs.getString("nombre"),
                        rs.getString("nombre_equipo"),
                        rs.getInt("goles")
                );
                reporte.append(linea);
            }
        } catch (Exception ex) {
            return "Error: " + ex.getMessage();
        } finally {
            conexion.desconectar();
        }
        return reporte.toString();

    }

    // Metodo para crear el reporte del historial
    public String getReporteHistorial() {
        //Instancia la conexion
        Conexion conexion = new Conexion();
        StringBuilder reporte = new StringBuilder();

        reporte.append("HISTORIAL DE PARTIDOS\n");
        String sql = "SELECT * FROM partidos ORDER BY fecha DESC";

        try {
            Connection con = conexion.conectar();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                String linea = rs.getString("equipoA") + " (" + rs.getInt("golesA") + ") vs ("
                        + rs.getInt("golesB") + ") " + rs.getString("equipoB") + "\n";
                reporte.append(linea);
            }
        } catch (Exception ex) {
            return "Error: " + ex.getMessage();
        } finally {
            conexion.desconectar();
        }
        return reporte.toString();

    }

    // Metodo para consultar equipos
    public DefaultTableModel consultarEquipos() {
        // Instancia la conexion
        Conexion conexion = new Conexion();
        DefaultTableModel modelo = new DefaultTableModel();

        modelo.addColumn("ID");
        modelo.addColumn("NOMBRE");
        modelo.addColumn("JUGADORES");
        modelo.addColumn("PUNTOS");

        String sql = "SELECT * FROM equipos";
        String[] datos = new String[4];

        try {
            Connection con = conexion.conectar();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                datos[0] = rs.getString("id");
                datos[1] = rs.getString("nombre");
                datos[2] = rs.getString("cantidad_jugadores");
                datos[3] = rs.getString("puntos");
                modelo.addRow(datos);
            }
        } catch (Exception ex) {
            System.out.println("Error al consultar equipos: " + ex.getMessage());
        } finally {
            conexion.desconectar();
        }
        return modelo;
    }

    // Metodo para agregar equipo
    public boolean agregarEquipo(String nombre) {
        Conexion conexion = new Conexion();
        // Insertamos solo el nombre
        String sql = "INSERT INTO equipos (nombre) VALUES (?)";

        try {
            Connection con = conexion.conectar();
            CallableStatement cs = con.prepareCall(sql);
            cs.setString(1, nombre);
            cs.execute();
            return true;
        } catch (Exception ex) {
            System.out.println("Error al crear equipo: " + ex.getMessage());
            return false;
        } finally {
            conexion.desconectar();
        }
    }

    // Metodo para elminar el equipo
    public boolean eliminarEquipo(String nombreEquipo) {
        // Instancia la conexion
        Conexion conexion = new Conexion();

        try {
            Connection con = conexion.conectar();

            // Los jugadores creados, ahora son liberados
            String sqlLiberar = "UPDATE jugadores SET nombre_equipo = 'Ninguno' WHERE nombre_equipo = ?";
            CallableStatement cs1 = con.prepareCall(sqlLiberar);
            cs1.setString(1, nombreEquipo);
            cs1.execute();

            // Borra el equipo
            String sqlBorrar = "DELETE FROM equipos WHERE nombre = ?";
            CallableStatement cs2 = con.prepareCall(sqlBorrar);
            cs2.setString(1, nombreEquipo);
            cs2.execute();

            return true;

        } catch (Exception ex) {
            System.out.println("Error al eliminar equipo: " + ex.getMessage());
            return false;
        } finally {
            conexion.desconectar();
        }
    }

    // Metodo para editar el jugador
    public boolean editarJugador(JugadorFutbol jugador) {

        // Instancia la conexion
        Conexion conexion = new Conexion();
        // Actualiza en BD
        String sql = "UPDATE jugadores SET nombre = ?, tipo_rol = ?, nombre_equipo = ? WHERE id = ?";

        try {
            Connection con = conexion.conectar();
            CallableStatement cs = con.prepareCall(sql);

            cs.setString(1, jugador.getNombre());
            cs.setString(2, jugador.getRol());
            cs.setString(3, jugador.getEquipo());
            cs.setInt(4, jugador.getId());

            cs.execute();
            return true;

        } catch (Exception ex) {
            // Atrapa cualquier error e imprime:
            System.out.println("Error al editar jugador: " + ex.getMessage());
            return false;
        } finally {
            conexion.desconectar();
        }
    }

    // Metodo para generar el reporte de rendimiento
    public String getReporteRendimiento() {
        Conexion conexion = new Conexion();
        StringBuilder reporte = new StringBuilder();

        reporte.append("RENDIMIENTO DE EQUIPOS\n");
        reporte.append(String.format("%-15s %5s %5s\n", "EQUIPO", "PJ", "%VIC"));

        String sql = "SELECT nombre, partidos_jugados, victorias FROM equipos";

        try {
            java.sql.Connection con = conexion.conectar();
            java.sql.Statement st = con.createStatement();
            java.sql.ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                String nombre = rs.getString("nombre");
                int pj = rs.getInt("partidos_jugados");
                int victorias = rs.getInt("victorias");

                // Calculo de porcentaje simple
                double porcentaje = 0;
                if (pj > 0) {
                    porcentaje = ((double) victorias / pj) * 100;
                }

                String linea = String.format("%-15s %5d %5.1f%%\n", nombre, pj, porcentaje);
                reporte.append(linea);
            }
        } catch (Exception ex) {
            return "Error: " + ex.getMessage();
        } finally {
            conexion.desconectar();
        }
        return reporte.toString();
    }

    // Metodo para sumar goles, reporte
    public void sumarGolJugador(int idJugador) {
        Conexion conexion = new Conexion();
        // Sumamos 1 gol al jugador
        String sql = "UPDATE jugadores SET goles = goles + 1 WHERE id = ?";

        try {
            java.sql.Connection con = conexion.conectar();
            java.sql.PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, idJugador);
            ps.executeUpdate();

        } catch (Exception ex) {
            System.out.println("Error al sumar gol al jugador: " + ex.getMessage());
        } finally {
            conexion.desconectar();
        }
    }
}

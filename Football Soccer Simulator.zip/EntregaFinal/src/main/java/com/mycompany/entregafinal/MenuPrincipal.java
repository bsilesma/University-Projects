package com.mycompany.entregafinal;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;

public class MenuPrincipal extends javax.swing.JFrame {

    // Instancia para la base de datos
    private Gestion gestor = new Gestion();
    // Guarda el ID del jugador
    private int idJugadorSeleccionado = -1;

    // Constructor
    public MenuPrincipal() {
        initComponents();
        setLocationRelativeTo(null);
        setTitle("Gestion de jugadores");
        cargarDatos();
        //Servidor
        ServidorHilo server = new ServidorHilo(5000);
        server.start();
    }

    // Metodo carga los datos de SQL
    private void cargarDatos() {
        jTableJugadores.setModel(gestor.consultarJugadores());
        jComboBoxEquipo.setModel(gestor.obtenerModeloEquipos());
        jComboBoxPosicion.setModel(new DefaultComboBoxModel<>(new String[]{"Portero", "Defensa", "Mediocampo", "Delantero"}));
    }

    // Metodo limpiarTodo
    private void limpiarFormulario() {
        txtNombre.setText("");
        if (jComboBoxPosicion.getItemCount() > 0) {
            jComboBoxPosicion.setSelectedIndex(0);
        }
        if (jComboBoxEquipo.getItemCount() > 0) {
            jComboBoxEquipo.setSelectedIndex(0);
        }
    }

    //-------------------------------------------------------------------------------------------
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        btnIngresar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnIniciarSimulacion = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        jComboBoxPosicion = new javax.swing.JComboBox<>();
        jComboBoxEquipo = new javax.swing.JComboBox<>();
        btnGestionarEquipos = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableJugadores = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Inicio de sesión");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "Gestion Jugadores", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Berlin Sans FB Demi", 1, 18))); // NOI18N

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Panel de botones", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Berlin Sans FB Demi", 1, 14))); // NOI18N

        btnIngresar.setText("Ingresar");
        btnIngresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIngresarActionPerformed(evt);
            }
        });

        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnIniciarSimulacion.setText("Iniciar simulacion");
        btnIniciarSimulacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIniciarSimulacionActionPerformed(evt);
            }
        });

        btnLimpiar.setText("Limpiar");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnIngresar)
                    .addComponent(btnEliminar)
                    .addComponent(btnIniciarSimulacion)
                    .addComponent(btnLimpiar)
                    .addComponent(btnEditar))
                .addContainerGap(16, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(btnIngresar)
                .addGap(18, 18, 18)
                .addComponent(btnEliminar)
                .addGap(18, 18, 18)
                .addComponent(btnLimpiar)
                .addGap(18, 18, 18)
                .addComponent(btnEditar)
                .addGap(18, 18, 18)
                .addComponent(btnIniciarSimulacion)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Registro Jugadores", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Berlin Sans FB Demi", 1, 14))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 14)); // NOI18N
        jLabel2.setText("Nombre:");

        jLabel4.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 14)); // NOI18N
        jLabel4.setText("Posicion:");

        jLabel3.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 14)); // NOI18N
        jLabel3.setText("Equipo:");

        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });

        jComboBoxEquipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Real Madrid", "Barcelona", "Ninguno" }));
        jComboBoxEquipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxEquipoActionPerformed(evt);
            }
        });

        btnGestionarEquipos.setText("Gestionar Equipos");
        btnGestionarEquipos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGestionarEquiposActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel2))
                .addGap(46, 46, 46)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 354, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBoxPosicion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jComboBoxEquipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnGestionarEquipos, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jComboBoxPosicion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jComboBoxEquipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnGestionarEquipos))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jTableJugadores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTableJugadores.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jTableJugadoresMousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(jTableJugadores);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 244, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Ignorar
    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreActionPerformed

    // Ignorar
    private void jComboBoxEquipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxEquipoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxEquipoActionPerformed

    // Boton Ingresar
    private void btnIngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIngresarActionPerformed
        try {
            // Obtiene los dsatos
            String nombre = txtNombre.getText();
            String rolTexto = (String) jComboBoxPosicion.getSelectedItem();
            String equipo = (String) jComboBoxEquipo.getSelectedItem();

            // Validar
            if (nombre.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Escriba un nombre.");
                return;
            }

            // Creamos el jugador
            JugadorFutbol nuevo = null;

            // Swtich para ver que se istancia despues
            switch (rolTexto) {
                case "Portero":
                    nuevo = new Portero(nombre);
                    break;
                case "Defensa":
                    nuevo = new Defensa(nombre);
                    break;
                case "Mediocampo":
                    nuevo = new Mediocampo(nombre);
                    break;
                case "Delantero":
                    nuevo = new Delantero(nombre);
                    break;
                default:
                    nuevo = new Defensa(nombre);
                    break;
            }

            nuevo.setEquipo(equipo);

            // Guarda en SQL
            if (gestor.agregarJugador(nuevo)) {
                JOptionPane.showMessageDialog(this, "Jugador guardado en base de datos");
                cargarDatos(); // Refrescamos la tabla para ver el nuevo
                limpiarFormulario();
            } else {
                JOptionPane.showMessageDialog(this, "Error al guardar en base de datos");
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }

    }//GEN-LAST:event_btnIngresarActionPerformed

    // Boton eliminar
    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        // Ver cual fila selecciona
        int fila = jTableJugadores.getSelectedRow();

        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un jugador de la tabla primero");
            return;
        }

        // Obtiene el ID
        String idTexto = jTableJugadores.getValueAt(fila, 0).toString();
        int id = Integer.parseInt(idTexto);

        String nombre = jTableJugadores.getValueAt(fila, 1).toString();

        // Doble confirmación
        int confirmacion = JOptionPane.showConfirmDialog(this, "¿Seguro que quiere borrar a: " + nombre + "?");

        if (confirmacion == JOptionPane.YES_OPTION) {
            // Borra los datos
            if (gestor.eliminarJugador(id)) {
                JOptionPane.showMessageDialog(this, "Eliminado correctamente");
                cargarDatos(); // Refrescamos la tabla
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo eliminar");
            }
        }

    }//GEN-LAST:event_btnEliminarActionPerformed

    // Boton iniciar simulacoin
    private void btnIniciarSimulacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIniciarSimulacionActionPerformed
        //Prendemos la interfaz
        InterfazFutbol ventanaNueva = new InterfazFutbol();
        ventanaNueva.setVisible(true);
    }//GEN-LAST:event_btnIniciarSimulacionActionPerformed

    //Boton limpiar
    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed

        limpiarFormulario();
    }//GEN-LAST:event_btnLimpiarActionPerformed

    // Boton editar
    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
        // Validacion
        if (idJugadorSeleccionado == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un jugador de la tabla para editar");
            return;
        }

        try {
            // Obtiene los datos
            String nombre = txtNombre.getText();
            String rolTexto = (String) jComboBoxPosicion.getSelectedItem();
            String equipo = (String) jComboBoxEquipo.getSelectedItem();

            // Validacion
            if (nombre.isEmpty()) {
                JOptionPane.showMessageDialog(this, "El nombre no puede estar vacío");
                return;
            }

            // Crea el jugador
            JugadorFutbol jugadorEditado = null;

            switch (rolTexto) {
                case "Portero":
                    jugadorEditado = new Portero(nombre);
                    break;
                case "Defensa":
                    jugadorEditado = new Defensa(nombre);
                    break;
                case "Mediocampo":
                    jugadorEditado = new Mediocampo(nombre);
                    break;
                case "Delantero":
                    jugadorEditado = new Delantero(nombre);
                    break;
                default:
                    jugadorEditado = new Defensa(nombre);
                    break;
            }

            // Actualiza ID y equipo
            jugadorEditado.setId(idJugadorSeleccionado);
            jugadorEditado.setEquipo(equipo);

            // Actualiza desde BD
            if (gestor.editarJugador(jugadorEditado)) {
                JOptionPane.showMessageDialog(this, "Jugador editado correctamente");
                cargarDatos();
                limpiarFormulario();
                idJugadorSeleccionado = -1;
            } else {
                JOptionPane.showMessageDialog(this, "Error al editar en la Base de Datos");
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }//GEN-LAST:event_btnEditarActionPerformed

    // Funcion para boton editar
    private void jTableJugadoresMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableJugadoresMousePressed
        int fila = jTableJugadores.getSelectedRow();

        if (fila != -1) {
            // Gurda el ID
            String idTexto = jTableJugadores.getValueAt(fila, 0).toString();
            idJugadorSeleccionado = Integer.parseInt(idTexto);

            // Llena el nombre
            txtNombre.setText(jTableJugadores.getValueAt(fila, 1).toString());

            // Llena con los cb
            String posicion = jTableJugadores.getValueAt(fila, 2).toString();
            jComboBoxPosicion.setSelectedItem(posicion);

            String equipo = jTableJugadores.getValueAt(fila, 3).toString();
            jComboBoxEquipo.setSelectedItem(equipo);
        }    }//GEN-LAST:event_jTableJugadoresMousePressed

    // Abre bentana
    private void btnGestionarEquiposActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGestionarEquiposActionPerformed
        new GestionEquipos().setVisible(true);
    }//GEN-LAST:event_btnGestionarEquiposActionPerformed

    // Main, ignorar la verdad
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGestionarEquipos;
    private javax.swing.JButton btnIngresar;
    private javax.swing.JButton btnIniciarSimulacion;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JComboBox<String> jComboBoxEquipo;
    private javax.swing.JComboBox<String> jComboBoxPosicion;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableJugadores;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables
}


package com.mycompany.entregafinal;


public class Defensa extends JugadorFutbol {

    
    // Mensajes predeterminados del defensa
    private final String[] mensajes = {
        "anticipa y roba el balón con limpieza",
        "cierra espacios y despeja con seguridad.",
        "gana un choque y mantiene la línea.",
        "corta una contra con una barrida precisa."
    };

    // Hereda todo de clase madre
    public Defensa(String nombre) {
        super(nombre);
    }

    // toString
    @Override
    public String generarMensaje() {
        int indiceAleatorio = (int) (Math.random() * mensajes.length);
        String frase = mensajes[indiceAleatorio];
        return "[Equipo: " + this.equipo + "] " + this.nombre + " " + frase;
    }
}

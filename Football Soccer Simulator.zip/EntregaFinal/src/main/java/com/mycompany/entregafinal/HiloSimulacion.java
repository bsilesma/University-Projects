package com.mycompany.entregafinal;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.JTextArea;

public class HiloSimulacion extends Thread {

    // Atributos
    private Equipo equipoA;
    private Equipo equipoB;
    private ArrayList<JugadorFutbol> jugadoresA; // Lista de titulares equipo A
    private ArrayList<JugadorFutbol> jugadoresB; // Lista de titulares equipo B

    // Cosas de la interfaz
    private JLabel lblMarcador;
    private JLabel lblMinuto;
    private JLabel lblEvento;
    private JTextArea txtBitacora;
    private JProgressBar barraTiempo;

    // Declara los goles en 0
    private int golesA = 0;
    private int golesB = 0;
    private boolean enJuego = true;

    // Constructor
    public HiloSimulacion(Equipo equipoA, Equipo equipoB,
            ArrayList<JugadorFutbol> jugadoresA, ArrayList<JugadorFutbol> jugadoresB,
            JLabel lblMarcador, JLabel lblMinuto, JLabel lblEvento,
            JTextArea txtBitacora, JProgressBar barraTiempo) {
        this.equipoA = equipoA;
        this.equipoB = equipoB;
        this.jugadoresA = jugadoresA;
        this.jugadoresB = jugadoresB;
        this.lblMarcador = lblMarcador;
        this.lblMinuto = lblMinuto;
        this.lblEvento = lblEvento;
        this.txtBitacora = txtBitacora;
        this.barraTiempo = barraTiempo;
    }

    // Empieza la mejengaaa
    public void run() {

        agregarBitacora("Vamos al futboool");

        // Instancia la barra de tiempo en 0 y max 40
        barraTiempo.setMinimum(0);
        barraTiempo.setMaximum(40);

        Random dado = new Random();

        // Loop de maximo 40 "minutos"
        for (int minuto = 1; minuto <= 40; minuto++) {

            try {
                // Pone en pausa el hilo mientras corre el tiempo
                int tiempoEspera = dado.nextInt(201) + 250;
                Thread.sleep(tiempoEspera);

                // Acutaliza el contador en pantalla
                lblMinuto.setText("Minuto: " + minuto);
                barraTiempo.setValue(minuto);

                // Jugada 
                boolean esEquipoA = dado.nextBoolean();
                Equipo equipoActual = esEquipoA ? equipoA : equipoB;
                ArrayList<JugadorFutbol> listaActual = esEquipoA ? jugadoresA : jugadoresB;

                // Dado con suerte
                int suerte = dado.nextInt(100) + 1;

                // Jugada
                if (suerte <= 70) {
                    // Se elije un jugador al azar
                    JugadorFutbol protagonista = obtenerJugadorAlAzar(listaActual);
                    String mensaje = protagonista.generarMensaje(); // Polimorfismo puro

                    actualizarEvento("JUGADA", Color.BLACK);
                    agregarBitacora(mensaje);
                } // Cambio de jugada
                else if (suerte <= 85) {
                    actualizarEvento("CAMBIO", Color.BLUE);
                    agregarBitacora("[Equipo: " + equipoActual.getNombre() + "] El técnico pide un cambio tactico.");
                } // Jugada
                else {
                    // Dentro de evento clave: 40% Gol, 30% Penal, 30% Tiro Libre
                    int tipoClave = dado.nextInt(100) + 1;

                    if (tipoClave <= 40) { // Si es gol
                        anotarGol(esEquipoA, listaActual);
                    } else if (tipoClave <= 70) { // Si es penal
                        agregarBitacora("[Equipo: " + equipoActual.getNombre() + "] ¡PENAL! El arbitro señala el manchón blanco.");
                        actualizarEvento("PENAL", Color.RED);
                        // Momento del penal
                        if (dado.nextInt(100) < 80) {
                            Thread.sleep(500); // Tananananaaaaan
                            anotarGol(esEquipoA, listaActual);
                        } else {
                            agregarBitacora("Peeerraaaa, lo falló");
                        }
                    } else { //Tiro libre
                        agregarBitacora("[Equipo: " + equipoActual.getNombre() + "] Tiro libre peligroso cerca del área...");
                        actualizarEvento("TIRO LIBRE", Color.ORANGE);
                        // Probabilidad
                        if (dado.nextInt(100) < 20) {
                            Thread.sleep(500); // TANANANNAAAAAN
                            anotarGol(esEquipoA, listaActual);
                        } else {
                            agregarBitacora("El centro es despejado por la defensa");
                        }
                    }
                }

            } catch (InterruptedException e) {
                System.out.println("Error en la simulacion: " + e.getMessage());
            }
        }

        // Se fue la mejenga
        agregarBitacora("Fin del partido");
        agregarBitacora("Marcador Final: " + equipoA.getNombre() + " " + golesA + " - " + golesB + " " + equipoB.getNombre());
        actualizarEvento("finalizado", Color.BLACK);

        try {
            // Llamamos al gestor para que guarde en MySQL
            Gestion gestor = new Gestion();
            gestor.registrarPartido(equipoA, equipoB, golesA, golesB);

            agregarBitacora(">> ¡Resultado y Estadísticas guardados en Base de Datos!");

        } catch (Exception e) {
            agregarBitacora(">> Error al guardar en BD: " + e.getMessage());
        }

    }

    //Metodos extra
    private void anotarGol(boolean esEquipoA, ArrayList<JugadorFutbol> lista) {
        // Obtiene data de quien metió el gol
        JugadorFutbol anotador = obtenerJugadorAlAzar(lista);

        if (esEquipoA) {
            golesA++;
        } else {
            golesB++;
        }

        // Actualizamos 
        lblMarcador.setText(equipoA.getNombre() + " " + golesA + " - " + golesB + " " + equipoB.getNombre());
        actualizarEvento("¡GOOOL!", new Color(0, 153, 51));
        agregarBitacora("¡GOOOL de " + anotador.getNombre() + "! (" + anotador.getRol() + ")");

        // Apuntamos el gol en 
        anotador.setGoles(anotador.getGoles() + 1);

        // Agrega a la BD
        Gestion gestorBD = new Gestion();
        gestorBD.sumarGolJugador(anotador.getId());
        // --------------------------------------------
    }

    // Metodo para a garrar un jugador random
    private JugadorFutbol obtenerJugadorAlAzar(ArrayList<JugadorFutbol> lista) {
        Random rand = new Random();
        int index = rand.nextInt(lista.size());
        return lista.get(index);
    }

    // Agregamos al txt 
    private void agregarBitacora(String texto) {
        // Agregamos al final con salto de linea
        txtBitacora.append(texto + "\n");
        txtBitacora.setCaretPosition(txtBitacora.getDocument().getLength());
    }

    // Actualiza
    private void actualizarEvento(String texto, Color color) {
        lblEvento.setText(texto);
        lblEvento.setForeground(color);
    }
}

package com.mycompany.entregafinal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    // Atributos
    private String url;
    private String db;
    private String user;
    private String password;
    private String driver;
    private Connection connection;

    //Conexión con SQL segun usuario y contrasena
    public Conexion() {
        this.url = "jdbc:mysql://localhost:3306/";
        this.db = "TorneoFutbolDB";
        this.user = "root";
        this.password = "dante";
        this.driver = "com.mysql.cj.jdbc.Driver";
    }

    // Realiza la conexion
    public Connection conectar() throws Exception {
        try {
            Class.forName(driver);
            connection = DriverManager.getConnection(url + db, user, password);
            return connection;
        } catch (ClassNotFoundException ex) {
            // Si no esta el archivo en la computadora, imprime: 
            System.out.println("Error: Driver no encontrado");
            throw new Exception("Error Driver");
        } catch (SQLException ex) {
            // Si hay un error en general, imprime:
            System.out.println("Error SQL: " + ex.getMessage());
            throw new Exception("Error Conexión");
        }
    }

    // Desconecta con la BD
    public void desconectar() {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException ex) {
                // Si algun error ocurre, imprime:
                System.out.println("Error desconexión: " + ex.getMessage());
            }
        }
    }
}
